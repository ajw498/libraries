extern int rpathz_value ();
int main () { return !(rpathz_value () == 5171); }
