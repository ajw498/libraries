extern int rpathx_value ();
int rpathy_value () { return 10 * rpathx_value () + 7; }
